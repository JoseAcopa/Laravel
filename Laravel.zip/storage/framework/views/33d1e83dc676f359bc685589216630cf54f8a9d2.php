<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Rayos X y Servicios Induxtriales</title>
    <link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:200" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome/css/font-awesome.min.css')); ?>">
  </head>
  <body class="fondo">
    <header>
      <nav class="nav-login">
        <ul class="ul">
          <li>RAYOS X Y SERVICIOS INDUSTRIALES S.A. DE C.V.</li>
        </ul>
      </nav>
    </header>
    <main class="wrapper">
      <form class="login" method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo e(csrf_field()); ?>


        <img src="<?php echo e(url('img/LogoRX.png')); ?>" alt="">
        <h1>Login</h1>

        <div class="<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
          <label for="users">Usuario</label>
          <div class="icon">
            <input type="text" id="users" value="" placeholder="usuario" value="<?php echo e(old('email')); ?>" required autofocus>
            <i class="fa fa-user" aria-hidden="true"></i>
          </div>
          <?php if($errors->has('email')): ?>
              <span class="help-block">
                  <strong><?php echo e($errors->first('email')); ?></strong>
              </span>
          <?php endif; ?>
        </div>

        <div class="<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
          <label for="pass">Contraseña</label>
          <div class="icon">
            <input type="password" id="pass" value="" placeholder="contraseña" required>
            <i class="fa fa-key" aria-hidden="true"></i>
          </div>
          <?php if($errors->has('password')): ?>
              <span class="help-block">
                  <strong><?php echo e($errors->first('password')); ?></strong>
              </span>
          <?php endif; ?>
        </div>
        <div class="login-button-lost">
          <button type="submit" class="btn-login">Login</button>
          <a href="#" class="lost"><p>Olvidaste tu contraseña?</p></a>
        </div>
      </form>
    </main>
    <footer id="footer-login">
      <p>© 2017 Todos Los Derechos Reservados</p>
    </footer>
  </body>
</html>
