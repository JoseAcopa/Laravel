<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
  protected $table = 'employee';
  // protected $id = "id";

  // public $timestamps = false;

  // protected $fillable = [
  //     'nombre_Empleado', 'telefono', 'usario', 'contrasena',
  // ];
}
