<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<?php $__env->startSection('head'); ?>
    <?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldSection(); ?>

<body class="hold-transition skin-blue fixed sidebar-mini">
    <div class="wrapper">

    <?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content-wrapper">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layouts.sidebarL', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


  <?php $__env->startSection('script'); ?>
      <?php echo $__env->make('layouts.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php echo $__env->yieldSection(); ?>
  </div>
</body>
</html>
