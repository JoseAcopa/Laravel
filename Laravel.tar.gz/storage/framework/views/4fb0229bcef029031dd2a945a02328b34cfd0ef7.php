<?php $__env->startSection('content'); ?>

    <section class="content-header">
      <h1>
        Administrador
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><i class="fa fa-dashboard"></i> Se encuentra en</li>
        <li class="active">Editar Cliente</li>
      </ol>
    </section>

    <section class="content container-fluid">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title"><i class="fa fa-edit"></i> Editar Cliente</h3>
        </div>
        <?php echo Form::model($client, ['method' => 'PATCH','route' => ['client.update', $client->id], 'role' => 'form']); ?>

          <?php echo e(csrf_field()); ?>

          <div class="box-body">
            <div class="col-md-6">
              <div class="form-group <?php echo e($errors->has('business') ? 'has-error' : ''); ?>">
                <label for="business">Nombre de la Empresa:</label>
                <input type="text" name="business" class="form-control" value='<?php echo e($client->business); ?>'>
                <?php echo $errors->first('business','<span class="help-block">:message</span>'); ?>

              </div>
              <div class="form-group <?php echo e($errors->has('RFC') ? 'has-error' : ''); ?>">
                <label for="RFC">RFC:</label>
                <input type="text" name="RFC" class="form-control" value='<?php echo e($client->RFC); ?>'>
                <?php echo $errors->first('RFC','<span class="help-block">:message</span>'); ?>

              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group <?php echo e($errors->has('phone') ? 'has-error' : ''); ?>">
                <label for="phone">Teléfono:</label>
                <input type="tel" name="phone" class="form-control" value='<?php echo e($client->phone); ?>'>
                <?php echo $errors->first('phone','<span class="help-block">:message</span>'); ?>

              </div>
              <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                <label for="email">E-mail:</label>
                <input type="email" name="email" class="form-control" value='<?php echo e($client->email); ?>'>
                <?php echo $errors->first('email','<span class="help-block">:message</span>'); ?>

              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">
                <label for="address">Dirección:</label>
                <textarea type="text" rows="6" class="form-control" name="address"><?php echo e($client->address); ?></textarea>
                <?php echo $errors->first('address','<span class="help-block">:message</span>'); ?>

              </div>
            </div>
          </div>
          <div class="box-footer">
            <button type="submit" class="btn btn-primary"><i class="fa fa-save fa-lg"></i> Guardar</button>
            <a href="<?php echo e(url('/admin/client')); ?>" class="btn btn-danger"><i class="fa fa-times-rectangle-o fa-lg"></i> Cancelar</a>
          </div>
        <?php echo Form::close(); ?>

      </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>