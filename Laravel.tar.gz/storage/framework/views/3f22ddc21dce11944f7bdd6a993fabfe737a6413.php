<?php $__env->startSection('content'); ?>

    <section class="content-header">
      <h1>
        Administrador
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><i class="fa fa-dashboard"></i> Se encuentra en</li>
        <li class="active">Catálogo</li>
      </ol>
    </section>

    <section class="content container-fluid">
      <?php if($message = Session::get('success')): ?>
        <div class="box box-success box-solid">
          <div class="box-header">
            <h3 class="box-title"><?php echo e($message); ?></h3>
            <div class="box-tools pull-right">
              <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
          </div>
        </div>
      <?php endif; ?>

      <div class="box">
        <div class="box-header">
          <?php if(auth()->user()->create === 1): ?>
            <a href="<?php echo e(url('admin/alta-producto-catalogo')); ?>" class="btn btn-success" ><i class="fa fa-pencil "></i> Alta de Productos</a>
          <?php endif; ?>
        </div>

        <div class="box-body">
          <table id="Jtabla" class="table table-bordered table-striped">
            <thead>
              <tr class="success">
                <th>Acciones</th>
                <th>Tipo de Producto</th>
                <th>Iniciales</th>
                <th>Proveedor</th>
                <th>Unidad</th>
                <th>Descripción</th>
             </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $catalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td class="row-copasat">
                    <?php if(auth()->user()->update === 1): ?>
                      <a class="btn btn-info" href="<?php echo e(url('/admin/editar-producto-catalogo',$product->id)); ?>"><i class="fa fa-pencil-square-o"></i></a>
                    <?php endif; ?>
                    <?php if(auth()->user()->delete === 1): ?>
                      <?php echo Form::open(['method' => 'DELETE','route' => ['catalogo.destroy', $product->id]]); ?>

                        <button type="submit" class="btn btn-danger"><i class="fa fa-trash-o"></i></button>
                      <?php echo Form::close(); ?>

                    <?php endif; ?>
                  </td>
                  <td><?php echo e($product->category->type); ?></td>
                  <td><?php echo e($product->letter); ?></td>
                  <td><?php echo e($product->supplier->business); ?></td>
                  <td><?php echo e($product->unit->type); ?></td>
                  <td><?php echo e($product->description); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>