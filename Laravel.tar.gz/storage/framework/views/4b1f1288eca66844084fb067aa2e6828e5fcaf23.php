<?php $__env->startSection('content'); ?>

    <section class="content-header">
      <h1>
        Administrador
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><i class="fa fa-dashboard"></i> Se encuentra en</li>
        <li class="active">Registrar Productos en Catálogo</li>
      </ol>
    </section>

    <section class="content container-fluid">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title"><i class="fa fa-pencil"></i> Registrar Producto en Catálogo</h3>
        </div>
        <form role="form" method="POST" action="/admin/catalogo">
          <?php echo e(csrf_field()); ?>

          <div class="box-body">
            <div class="col-md-6">
              <div class="form-group <?php echo e($errors->has('category') ? 'has-error' : ''); ?>">
                <label for="category">Tipo de Producto:</label>
                <select class="form-control" name="category" onchange="typeProduct(this);">
                  <option value="">Seleccione Tipo Producto</option>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($categorie->id); ?>"><?php echo e($categorie->type); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php echo $errors->first('category','<span class="help-block">:message</span>'); ?>

              </div>
              <div class="form-group <?php echo e($errors->has('letter') ? 'has-error' : ''); ?>">
                <label for="initials" >Iniciales</label>
                <input class="form-control" type="text" id="letter" name="letter" readonly>
                <input type="text" id="categoria" name="tipo_categoria" hidden>
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group <?php echo e($errors->has('proveedor') ? 'has-error' : ''); ?>">
                <label for="proveedor">Proveedor:</label>
                <select class="form-control" name="proveedor">
                  <option value="">Seleccione Proveedor</option>
                  <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->business); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php echo $errors->first('proveedor','<span class="help-block">:message</span>'); ?>

              </div>
              <div class="form-group <?php echo e($errors->has('unidad') ? 'has-error' : ''); ?>">
                <label for="unidad">Unidad de Medida:</label>
                <select class="form-control" name="unidad">
                  <option value="">Seleccione Unidad de Medida</option>
                  <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($unit->id); ?>"><?php echo e($unit->type); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php echo $errors->first('unidad','<span class="help-block">:message</span>'); ?>

              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                <label for="description">Descripción:</label>
                <textarea type="text" rows="6" name="description" id="description" class="form-control" placeholder="Descripción"><?php echo e(old('description')); ?></textarea>
                <?php echo $errors->first('description','<span class="help-block">:message</span>'); ?>

              </div>
            </div>
          </div>
          <div class="box-footer">
            <button type="submit" class="btn btn-primary"><i class="fa fa-save fa-lg"></i> Guardar</button>
            <a href="<?php echo e(url('admin/catalogo')); ?>" class="btn btn-danger"><i class="fa fa-times-rectangle-o fa-lg"></i> Cancelar</a>
          </div>
        </form>
      </div>
    </section>
    <script type="text/javascript">
      function typeProduct(val){
        var categories = <?php echo$categories;?>;
        var newVal = {};

        categories.map((item)=>{
          newVal[item.id] = item
        })

        var category = newVal[val.value]
        document.getElementById('letter').value = category.letters;
        document.getElementById('categoria').value = category.categorias;
      }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>