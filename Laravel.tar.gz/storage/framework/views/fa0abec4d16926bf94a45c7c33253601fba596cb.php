<?php $__env->startSection('content'); ?>

    <section class="content-header">
      <h1>
        Administrador
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><i class="fa fa-dashboard"></i> Se encuentra en</li>
        <li class="active">Clasificación de Producto</li>
      </ol>
    </section>

    <section class="content container-fluid">
      <?php if($message = Session::get('success')): ?>
        <div class="box box-success box-solid">
          <div class="box-header">
            <h3 class="box-title"><?php echo e($message); ?></h3>
            <div class="box-tools pull-right">
              <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
          </div>
        </div>
      <?php endif; ?>

      <div class="box">
        <div class="box-header">
          <h4><i class="fa fa-pencil-square"></i> Clasificación de Producto</h4>
        </div>

        <div class="box-body">
          <div class="col-md-4">
            <form rol="form" method="POST" action="/admin/clasificationProduct">
              <?php echo e(csrf_field()); ?>

              <div class="box-body">
                <div class="form-group <?php echo e($errors->has('type') ? 'has-error' : ''); ?>">
                  <label for="typeP">Tipo de Producto:</label>
                  <input type="text" name="type" id="type" class="form-control" >
                  <?php echo $errors->first('type','<span class="help-block">:message</span>'); ?>

                </div>
                <div class="form-group <?php echo e($errors->has('letters') ? 'has-error' : ''); ?>">
                  <label for="ini">Iniciales:</label>
                  <input type="text" name="letters" id="name" class="form-control" >
                  <?php echo $errors->first('letters','<span class="help-block">:message</span>'); ?>

                </div>
                <div class="form-group <?php echo e($errors->has('categorias') ? 'has-error' : ''); ?>">
                  <label for="ini">Iniciales:</label>
                  <select name="categorias" id="name" class="form-control" >
                    <option value="">Seleccione Categoria</option>
                    <option value="Petrolera | Industrial">Petrolera | Industrial</option>
                    <option value="Hidraulica">Hidraulica</option>
                    <option value="Otro">Otro</option>
                  </select>
                  <?php echo $errors->first('categorias','<span class="help-block">:message</span>'); ?>

                </div>
              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary"><i class="fa fa-save fa-lg"></i> Guardar</button>
              </div>
            </form>
          </div>
          <div class="col-md-8">
            <table class="table table-bordered table-striped">
              <thead>
                <tr class="success">
                  <th>Acciones</th>
                  <th>Tipo de Producto</th>
                  <th>Letra Inicial</th>
                  <th>Categoria</th>
               </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="row-copasat">
                      
                      <?php echo Form::open(['method' => 'DELETE','route' => ['clasificationProduct.destroy', $key->id]]); ?>

                        <button type="submit" class="btn btn-danger"><i class="fa fa-trash-o"></i></button>
                      <?php echo Form::close(); ?>

                    </td>
                    <td><?php echo e($key->type); ?></td>
                    <td><?php echo e($key->letters); ?></td>
                    <td><?php echo e($key->categorias); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>