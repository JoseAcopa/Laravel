<?php $__env->startSection('content'); ?>

    <section class="content-header">
      <h1>
        Administrador
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><i class="fa fa-dashboard"></i> Se encuentra en</li>
        <li class="active">Proveedores</li>
      </ol>
    </section>

    <section class="content container-fluid">
      <?php if($message = Session::get('success')): ?>
        <div class="box box-success box-solid">
          <div class="box-header">
            <h3 class="box-title"><?php echo e($message); ?></h3>
            <div class="box-tools pull-right">
              <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
            </div>
          </div>
        </div>
      <?php endif; ?>

      <div class="box">
        <div class="box-header">
          <?php if(auth()->user()->create === 1): ?>
            <a href="<?php echo e(url('/admin/add-suppliers')); ?>" class="btn btn-success" ><i class="fa fa-user-plus"></i> Registrar Proveedores</a>
          <?php endif; ?>
        </div>

        <div class="box-body">
          <table id="Jtabla" class="table table-bordered table-striped">
            <thead>
              <tr class="success">
                <th>Acciones</th>
                <th>RFC</th>
                <th>Nombre de la Empresa</th>
                <th>Dirección</th>
                <th>Teléfono</th>
                <th>E-mail</th>
             </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="row-copasat">
                      <?php if(auth()->user()->update === 1): ?>
                        <a class="btn btn-info" href="<?php echo e(url('admin/edit-suppliers',$supplier->id)); ?>"><i class="fa fa-pencil-square-o"></i></a>
                      <?php endif; ?>
                      <?php if(auth()->user()->delete === 1): ?>
                        <?php echo Form::open(['method' => 'DELETE','route' => ['suppliers.destroy', $supplier->id]]); ?>

                          <button type="submit" class="btn btn-danger"><i class="fa fa-trash-o"></i></button>
                        <?php echo Form::close(); ?>

                      <?php endif; ?>
                    </td>
                    <td><?php echo e($supplier->RFC); ?></td>
                    <td><?php echo e($supplier->business); ?></td>
                    <td><?php echo e($supplier->address); ?></td>
                    <td><?php echo e($supplier->phone); ?></td>
                    <td><?php echo e($supplier->email); ?></td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>