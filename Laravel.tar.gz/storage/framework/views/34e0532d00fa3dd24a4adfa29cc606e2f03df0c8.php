<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      Developed by COPASAT
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2018 <a href="http://www.rayosxyservicios.com.mx/" target="_blank">Rayos X y Servicios Industriales S.A. de C.V</a>.</strong> Todos los derechos reservados.
</footer>
